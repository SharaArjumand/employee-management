#include <stdio.h>

struct Employee {
    int id;
    char name[50];
    float salary;
};

int main() {
    struct Employee emp[50];
    int n = 0, choice, i;

    while (1) {
        printf("\n1. Add Employee\n");
        printf("2. Show Employees\n");
        printf("3. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        if (choice == 1) {
            printf("Enter ID: ");
            scanf("%d", &emp[n].id);
            printf("Enter Name: ");
            scanf(" %[^\n]", emp[n].name);
            printf("Enter Salary: ");
            scanf("%f", &emp[n].salary);
            n++;
            printf("Employee Added!\n");
        }
        else if (choice == 2) {
            if (n == 0) {
                printf("No employees yet.\n");
            } else {
                for (i = 0; i < n; i++) {
                    printf("ID: %d | Name: %s | Salary: %.2f\n",
                           emp[i].id, emp[i].name, emp[i].salary);
                }
            }
        }
        else if (choice == 3) {
            printf("Goodbye!\n");
            break;
        }
        else {
            printf("Invalid choice!\n");
        }
    }

    return 0;
}
